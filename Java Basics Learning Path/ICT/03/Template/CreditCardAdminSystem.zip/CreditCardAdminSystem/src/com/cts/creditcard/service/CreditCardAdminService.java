/***********************************************************************************************************
 * This class CreditCardAdminService is used to handle business logic for the proposed system.
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/
package com.cts.creditcard.service;

import java.util.List;

import com.cts.creditcard.exception.CreditCardAdminSystemException;
import com.cts.creditcard.vo.CreditCard;

public class CreditCardAdminService {

	/**
	 * @param records
	 * @return List<Customer>
	 */
	public static List<CreditCard> buildMasterCreditCardList(List<String> records) {
		// TODO Add your logic here

		return null; // TODO change this return value
	}

	/**
	 * @param billAmount
	 * @return Double
	 */
	public static Double getBillAmountWithLatePaymentCharges(Double billAmount) {
		// TODO add your logic here
		return 0.00; // TODO change this return value
	}

	/**
	 * @param inputFeed
	 * @return Boolean
	 * @throws CreditCardAdminSystemException
	 */
	public Boolean addCreditCardDetails(String inputFeed) throws CreditCardAdminSystemException {
		// TODO add your logic here

		return null; //TODO change this return value
	}

}
