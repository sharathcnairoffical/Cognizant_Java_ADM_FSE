/***********************************************************************************************************
 * This class MainApp is used to run the service methods and to test the database.
 * 
 * YOU CAN INVOKE THE METHODS AS REQUIRED FROM HERE TO TEST THE APP
 * DO NOT USE VIA COMMAND LINE ARGUMENTS FROM MAIN METHOD, UNLESS SPECIFIED
 *
************************************************************************************************************/
package com.cts.creditcard.main;

public class MainApp {
	public static void main(String ag[]) {
		 //TODO add your code here
	}
}
