/**
 * 
 */
package com.cts.creditcard.exception;

/**
 * @author 222805
 *
 */
public class CreditCardAdminSystemException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1105431869622052445L;

	/**
	 * @param message
	 * @param cause
	 */
	public CreditCardAdminSystemException(String message, Throwable cause) {
		 super(message, cause);
	}
}
