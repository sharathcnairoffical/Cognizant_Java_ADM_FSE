package com.cts.conctes.client;

import com.cts.conctes.service.ConstructionProjectEstimationService;

public class CostAndTimeEstimation {

	public static void main(String[] args)
	{
		ConstructionProjectEstimationService cpeService = new ConstructionProjectEstimationService();
		//WRITE YOUR CODE HERE
		
	}
}
