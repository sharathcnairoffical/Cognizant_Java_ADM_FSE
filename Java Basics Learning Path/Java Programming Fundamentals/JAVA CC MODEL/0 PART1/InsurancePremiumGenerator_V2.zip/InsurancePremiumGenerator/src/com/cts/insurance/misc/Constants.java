package com.cts.insurance.misc;

public class Constants {
	public final static String YES = "Yes";
	public final static String NO = "No";
	public final static double MIN_PREMIUM_AMOUNT = 5000;
	public final static int MIN_HOUSEHOLD_VALUATION=0;
}
