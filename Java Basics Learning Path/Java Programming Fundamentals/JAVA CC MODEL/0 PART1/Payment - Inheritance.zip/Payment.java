
public class Payment {
    private int dueAmount;
    
    public int getDueAmount() {
        return dueAmount;
    }
    
    public void setDueAmount(int dueamount) {
        this.dueAmount = dueamount;
    }
    
    public boolean payAmount() {
      
       
      return false;
    }
    
}