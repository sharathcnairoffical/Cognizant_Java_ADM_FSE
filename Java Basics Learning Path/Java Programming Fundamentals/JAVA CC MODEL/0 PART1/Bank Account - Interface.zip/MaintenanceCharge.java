
public interface MaintenanceCharge 
{
    
    // create the abstract method
    
    float calculateMaintenanceCharge(float noOfYears);
    
    
}