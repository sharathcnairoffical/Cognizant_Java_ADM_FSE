package com.cts.entity;

public class CreditCard {
	private String number;

	public CreditCard() {
		
	}

	public CreditCard(String number) {
		super();
		this.number = number;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
	
	
}
