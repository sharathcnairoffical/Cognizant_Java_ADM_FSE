
public interface NumberType 
{
    public boolean checkNumberType(int n);
}