
public interface Calculate {
    
    float performCalculation(int a,int b);
}