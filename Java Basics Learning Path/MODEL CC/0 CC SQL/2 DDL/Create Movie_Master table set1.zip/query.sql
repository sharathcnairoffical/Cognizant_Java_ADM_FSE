create table Movie_Master(
MOVIE_ID varchar(5) primary key,
MOVIE_NAME varchar(4) not null,
DIRECTOR_NAME varchar(4) not null,
CERTIFICATION varchar(4) not null,
DURATION INT(3),
LANGUAGE varchar(10)
);