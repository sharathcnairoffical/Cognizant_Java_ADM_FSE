alter table patient modify
contact_number int(10);
alter table patient change p_age patient_age int;